To run the tests please have python3 installed and run:

    RSA: python3 rsa.py
    AES: python3 aes.py
    SHA256: python3 sha.py

If you do not want the log files, please alter the code to not save the logs as they can be very very large!

Enjoy :)